# -*- coding: utf-8 -*-
"""
Skript zum Lesen von Scans der Spendenbriefe, Extrahieren des Textes aus den Briefen und Speichern als txt-Dateien.
"""
from pdf2image import convert_from_path
import pytesseract
import glob
import os


def create_output_folder(pdf_path):
    output_folder = f"{pdf_path[:-4]}"
    if not os.path.exists(output_folder):
        os.makedirs(output_folder, exist_ok=True)

    return output_folder


def extract_text_from_image(img_blob):
    text = pytesseract.image_to_string(img_blob, lang='deu')
    return text


def save_text_to_file(text, output_folder, pdf_path, page_num):
    file_name = f"{output_folder}/{pdf_path[:-4]}_page{page_num}.txt"
    with open(file_name, 'w', encoding="utf-8") as txt_file:
        txt_file.write(text)


def convert_pdf_to_images(pdf_path, dpi=500):
    return convert_from_path(pdf_path, dpi)


def process_pdf(pdf_path):
    output_folder = create_output_folder(pdf_path)
    pages = convert_pdf_to_images(pdf_path)
    for page_num, img_blob in enumerate(pages):
        text = extract_text_from_image(img_blob)
        save_text_to_file(text, output_folder, pdf_path, page_num)


def scan_to_txt(scans_path):
    pdfs = glob.glob(scans_path)
    for pdf_path in pdfs:
        process_pdf(pdf_path)


if __name__ == "__main__":
    scan_to_txt(r"Spenden Teil 1.pdf")
