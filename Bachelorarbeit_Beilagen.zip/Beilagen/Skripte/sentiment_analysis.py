# -*- coding: utf-8 -*-
"""
Führt eine Sentimentanalyse mit einem Klassifikationsmodell von Hugging-Face durch.
"""
from germansentiment import SentimentModel
import os
import matplotlib.pyplot as plt

model = SentimentModel()
folder_path = r'./Brief_Segmente'
counter = 0
sentiment_counts = {'positive': 0, 'negative': 0, 'neutral': 0}

for file in os.listdir(path=folder_path):
    full_path = os.path.join(folder_path, file)
    print(full_path)

    # Change for specific functional units.
    if full_path[:-4].endswith('_4'):

        with open(full_path, 'r', encoding='utf-8') as current_text:
            # Toggle for word-level analysis.
            text = current_text.read().split(' ')

            # Toggle for sentence-level analysis.
            # text = current_text.readlines()
            # text = [line.strip() for line in text if line.strip()]

            classes, probabilities = model.predict_sentiment(text, output_probabilities=True)

            for item in zip(text, classes, probabilities):
                text, sentiment = item[0], item[1]
                sentiment_counts[sentiment] += 1
                print(f"Sentiment: {sentiment} | Text: {item[0]} | Probabilities: {[str(prob)[:18] for prob in item[2]]}")

print(sentiment_counts)
overall_counts = sum(sentiment_counts.values())
print('Overall counts: ', overall_counts)
negative_percent = (sentiment_counts['negative'] / overall_counts) * 100
print('Percent of negative words: ', negative_percent)
positive_percent = (sentiment_counts['positive'] / overall_counts) * 100
print('Percent of positive words: ', positive_percent)

"""Toggle for parsing of manually selected texts. Replace with section above."""
# text = ['unbeherrscht']
#
# classes, probabilities = model.predict_sentiment(text, output_probabilities=True)
# for item in zip(text, classes, probabilities):
#     text, sentiment = item[0], item[1]
#     sentiment_counts[sentiment] += 1
#     print(f"Sentiment: {sentiment} | Text: {item[0]} | Probabilities: {[str(prob)[:18] for prob in item[2]]}")

"""Toggle for visualization."""
# plt.bar(sentiment_counts.keys(), sentiment_counts.values())
# plt.xlabel('Sentiment')
# plt.ylabel('Count')
# plt.title('Sentiment Distribution')
# plt.show()