# -*- coding: utf-8 -*-
"""
Analyse der RST-Bäume in Form von RS3-Dateien. Iteriert über die RS3-Dateien im Ordner und führt Analysen durch.
Die Ergebnisse werden als prints ausgegeben.
"""
import xml.etree.ElementTree as ET
import os
import re
import matplotlib.pyplot as plt


class RSTAnalyser:
    def __init__(self, folder_path):
        self.folder_path = folder_path  # Path to the RSTs folder.
        self.file_path = ''  # Path to the current file in the folder iteration.
        self.all_elements = {}  # All the elements in the file and their information.
        self.relations = {}  # Count occurrences of relations across all files.
        self.overall_arcs = {'Forward': 0, 'Backward': 0}
        self.overall_total_arcs = 0
        self.files_count = 0
        self.iterate_folder()
        # self.plot_relation_dist()  # Toggle for plotting the relation distribution.

        print('Files count: ', self.files_count)
        print(self.overall_arcs['Forward'])
        print(self.overall_arcs['Backward'])
        print('Overall percent of Forward Arcs: ', (self.overall_arcs['Forward'] / self.files_count))
        print('Overall percent of Backward Arcs: ', (self.overall_arcs['Backward'] / self.files_count))

    def iterate_folder(self):
        for filename in os.listdir(self.folder_path):
            if filename.endswith("_3.rs3"):  # Toggle for specific segments of the Spendenbriefe.
            # if filename.endswith(".rs3"):  # Toggle for Briefe as whole.
                self.file_path = os.path.join(self.folder_path, filename)
                print('*' * 140)
                print("Processing:", self.file_path)
                # Create a dictionary containing all the elements in the rs3 file.
                self.rs3_to_dicts()

                # Count all relations in current file and add to overall relations counter.
                self.count_relations()
                total_relations_num = sum(
                    self.relations.values())  # Count the overall number of relations across all text files.
                print('total_relations_num: ', total_relations_num)
                # Compare forward and backwards arcs.
                self.compare_arcs()

                # Find the central unit(s) of the text.
                central_unit = self.get_central_unit('1')
                print(central_unit)
                print('Central units: ', re.findall(r'\d+', str(central_unit)))

                # Reset parameters.
                self.files_count += 1
                self.all_elements = {}
                print('*' * 140)

    def rs3_to_dicts(self):
        """Creates a dictionary with all the elements in the structure."""
        # Parse the rs3 file.
        tree = ET.parse(self.file_path)
        root = tree.getroot()

        # Create a dictionary for each segment in the rs3 file.
        for segment in root.findall('.//segment'):
            segment_id = segment.get('id')
            parent = segment.get('parent')
            relation = segment.get('relname')
            text = segment.text
            current_segment_dict = {"ID": segment_id, "Element": "segment", "Parent": parent, "Relation": relation,
                                    "Text": text}
            # Add the current segment to the dictionary containing all elements in the structure.
            self.all_elements[segment_id] = current_segment_dict

        # Create a dictionary for each group in the rs3 file.
        for group in root.findall('.//group'):
            group_id = group.get('id')
            parent = group.get('parent')
            relation = group.get('relname', None)

            current_group_dict = {"ID": group_id, "Element": "group", "Parent": parent, "Relation": relation}
            # Add current group to the dictionary containing all elements in the structure.
            self.all_elements[group_id] = current_group_dict

    def count_relations(self):
        for edu in self.all_elements:
            relation = self.all_elements[edu]['Relation']
            if relation in self.relations:
                self.relations[relation] += 1
            else:
                self.relations[relation] = 1

        if 'span' in self.relations.keys():
            del self.relations['span']
        if self.relations[None]:
            del self.relations[None]
        self.relations = dict(sorted(self.relations.items(), key=lambda item: item[1], reverse=True))

    def plot_relation_dist(self):
        # Set labels and counts.
        labels = list(self.relations.keys())
        counts = list(self.relations.values())

        # Plotting.
        plt.figure(figsize=(10, 4.5))
        plt.barh(labels, counts, color='skyblue')
        plt.xlabel('Count')
        plt.ylabel('Relation')
        plt.title('Relation Distribution')
        plt.gca().invert_yaxis()
        plt.grid(axis='x')

        max_count = max(counts)
        plt.xticks(range(0, max_count + 10, 25))

        plt.tight_layout()
        plt.show()

    def compare_arcs(self):
        arcs = {'Forward': 0, 'Backward': 0}
        for relation in self.all_elements:
            current_edu = self.all_elements[relation]
            if current_edu['Relation'] not in ['span', 'list', 'conjunction', 'contrast']:
                if str(current_edu['ID']) < str(current_edu['Parent']):
                    arcs['Forward'] += 1
                else:
                    arcs['Backward'] += 1

        total_relations = arcs['Forward'] + arcs['Backward']
        self.overall_total_arcs += total_relations
        print('Total relations: ', total_relations)
        forward_percent = (arcs['Forward'] / total_relations) * 100
        print('forward_percent: ', forward_percent)
        backward_percent = (arcs['Backward'] / total_relations) * 100
        print('backward_percent: ', backward_percent)
        self.overall_arcs['Forward'] += forward_percent
        self.overall_arcs['Backward'] += backward_percent

    def get_central_unit(self, node):
        children = []
        for segment in self.all_elements:
            if self.all_elements[segment]['Parent'] == node:
                children.append(segment)

        central_units = []
        for child in children:
            if self.all_elements[child]['Element'] == 'group' and \
               self.all_elements[child]['Relation'] in ['span', 'list', 'conjunction', 'contrast']:
                central_units.append(self.get_central_unit(child))
            elif self.all_elements[child]['Element'] == 'segment' and self.all_elements[child]['Relation'] \
                                                                  in ['span', 'list', 'conjunction', 'contrast']:
                central_units.append(child)
                break

        return central_units


# Analyze entire text.
entire_text_path = r'./Briefe'
RSTAnalyser(entire_text_path)

# # Analyze separate segments.
# segments_path = r'./Brief_segments'
# RSTAnalyser(segments_path)

# # Analyze PCC-Gold texts.
# pcc_parser = r'PotsdamCommentaryCorpus/rst'
# RSTAnalyser(pcc_parser)

# # Analyze PCC-Parser texts.
# pcc_parser = r'PotsdamCommentaryCorpus/Sara_parser'
# RSTAnalyser(pcc_parser)
