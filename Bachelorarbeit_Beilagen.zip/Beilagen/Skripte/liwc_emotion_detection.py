# -*- coding: utf-8 -*-
"""
Analyse der Wörter im Korpus, die im LIWC-Lexikon enthalten sind, zusammen mit ihrer Kategorien.
"""
from nltk.tokenize import word_tokenize
from nltk.stem import SnowballStemmer
from collections import defaultdict
import os
import nltk
from nltk.corpus import stopwords

stemmer = SnowballStemmer("german")
nltk.download('stopwords')  # Toggle off after first run.
stop_words = set(stopwords.words('german'))


def parse_liwc_dictionary(file_path):
    liwc_dict = defaultdict(list)

    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    lines = [line.strip() for line in lines if line.strip() and not line.startswith('%')]

    categories_index = {}
    for line in lines:
        if line[0].isalpha():
            # Line is a word with categories.
            elements = line.split('\t')
            word = elements[0].strip()
            categories = [int(cat) for cat in elements[1:] if cat.isdigit()]
            if '*' in word:
                pattern = word.replace('*', '')  # Remove * from words and add to dict.
                liwc_dict[pattern].extend(categories)
            else:
                liwc_dict[word].extend(categories)
        elif line[0].isdigit():
            # Extract category.
            elements = line.split('\t')
            categories_index[int(elements[0])] = elements[1]

    return liwc_dict, categories_index


def preprocess_text(text):
    tokens = word_tokenize(text.lower())
    return [token for token in tokens if token.isalpha()]


def stem_word(word):
    return stemmer.stem(word)


def find_word_categories(tokens, liwc_dict):
    word_categories = {}
    for token in tokens:
        stemmed_token = stem_word(token)
        if token in liwc_dict:
            word_categories[token] = liwc_dict[token]
        elif stemmed_token in liwc_dict:
            word_categories[stemmed_token] = liwc_dict[stemmed_token]
        else:
            word_categories[token] = []

    return word_categories


def count_categories(words_with_categories):
    categories_count = {}
    for token in words_with_categories.keys():
        for category in words_with_categories[token]:
            if category in categories_count:
                categories_count[category] += 1
            else:
                categories_count[category] = 1

    return categories_count


def replace_num_with_category(categories_count, categories_index):
    result_dict = {}

    for key, value in categories_count.items():
        new_key = categories_index.get(key)
        if new_key:
            result_dict[new_key] = value

    return result_dict


liwc_dict, categories_index = parse_liwc_dictionary('LIWC_German.txt')
folder_path = r'./Brief_Segmente'  # Toggle for segments.
# folder_path = r'./Briefe'  # Toggle for entire letters.

most_frequent_categories = {}
for file in os.listdir(path=folder_path):
    full_path = os.path.join(folder_path, file)
    # if full_path[:-4].endswith('_4'):  # Toggle for specific segments.
    if full_path[:-4]:  # Toggle for entire letters or all segments together.
        with open(full_path, 'r', encoding='utf-8') as current_text:
            text = current_text.read()
            tokens = preprocess_text(text)
            filtered_tokens = [token for token in tokens if token not in stop_words]  # Remove stopwords.
            words_category_dict = find_word_categories(filtered_tokens, liwc_dict)
            categories_count = count_categories(words_category_dict)
            for category, count in categories_count.items():
                if category not in most_frequent_categories:
                    most_frequent_categories[category] = count
                else:
                    most_frequent_categories[category] += count

sorted_categories_frequency = dict(sorted(most_frequent_categories.items(), key=lambda item: item[1], reverse=True))
final_dict = replace_num_with_category(sorted_categories_frequency, categories_index)
tokens_count = sum(final_dict.values())
percent_dict = {category: f'{(count / tokens_count) * 100: .2f}%' for category, count in final_dict.items()}
print(final_dict)
print('Tokens count: ', tokens_count)
print(percent_dict)
